-- MySQL dump 10.13  Distrib 5.1.49, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: nqdata
-- ------------------------------------------------------
-- Server version	5.1.49-3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Datab�ze: `nqdata`
--
DROP DATABASE IF EXISTS `nqdata`;
CREATE DATABASE `nqdata` DEFAULT CHARACTER SET utf8 COLLATE utf8_czech_ci;
USE `nqdata`;

--
-- Table structure for table `AbilityList`
--

DROP TABLE IF EXISTS `AbilityList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AbilityList` (
  `idAbility` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) COLLATE utf8_czech_ci NOT NULL,
  `Description` varchar(250) COLLATE utf8_czech_ci NOT NULL,
  PRIMARY KEY (`idAbility`),
  UNIQUE KEY `Name` (`Name`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AbilityList`
--

LOCK TABLES `AbilityList` WRITE;
/*!40000 ALTER TABLE `AbilityList` DISABLE KEYS */;
INSERT INTO `AbilityList` VALUES (20,'Java','Uživatel je schopen používat: Java'),(21,'C#','Uživatel je schopen používat: C#'),(22,'PHP','Uživatel je schopen používat: PHP'),(23,'SQL','Uživatel je schopen používat: SQL'),(24,'Python','Uživatel je schopen používat: Python'),(25,'Perl','Uživatel je schopen používat: Perl'),(26,'Brainfuck','Uživatel je schopen používat: Brainfuck'),(27,'Assembler','Uživatel je schopen používat: Assembler'),(28,'Windows','Uživatel je schopen používat: Windows'),(29,'Linux','Uživatel je schopen používat: Linux'),(30,'Bash','Uživatel je schopen používat: Bash'),(31,'Pascal','Uživatel je schopen používat: Pascal'),(32,'Visual Basic','Uživatel je schopen používat: Visual Basic'),(33,'VHDL','Uživatel je schopen používat: VHDL'),(34,'UML','Uživatel je schopen používat: UML'),(35,'XML','Uživatel je schopen používat: XML'),(36,'HTML','Uživatel je schopen používat: HTML'),(37,'CSS','Uživatel je schopen používat: CSS');
/*!40000 ALTER TABLE `AbilityList` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Projects`
--

DROP TABLE IF EXISTS `Projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Projects` (
  `idProject` int(11) NOT NULL,
  `idUserCreatedBy` int(11) NOT NULL,
  `idLeader` int(11) DEFAULT NULL,
  `Name` varchar(30) COLLATE utf8_czech_ci NOT NULL,
  PRIMARY KEY (`idProject`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Projects`
--

LOCK TABLES `Projects` WRITE;
/*!40000 ALTER TABLE `Projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `Projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TaskAbility`
--

DROP TABLE IF EXISTS `TaskAbility`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TaskAbility` (
  `idTask` int(11) NOT NULL,
  `idAbility` int(11) NOT NULL,
  `Level` int(5) NOT NULL,
  KEY `idTask` (`idTask`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TaskAbility`
--

LOCK TABLES `TaskAbility` WRITE;
/*!40000 ALTER TABLE `TaskAbility` DISABLE KEYS */;
/*!40000 ALTER TABLE `TaskAbility` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tasks`
--

DROP TABLE IF EXISTS `Tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tasks` (
  `idTask` int(11) NOT NULL AUTO_INCREMENT,
  `idProject` int(11) NOT NULL,
  `idUserCreatedBy` int(11) NOT NULL,
  `idUserAssignedTo` int(11) NOT NULL,
  `idParentTask` int(11) NOT NULL,
  `TaskStatus` enum('Created','Assigned','InProgress','Rejected','ApprovedWaiting','Completed') COLLATE utf8_czech_ci NOT NULL DEFAULT 'Created',
  `Title` varchar(30) COLLATE utf8_czech_ci NOT NULL,
  `Description` varchar(1000) COLLATE utf8_czech_ci NOT NULL,
  `Priority` int(11) NOT NULL,
  `CreationDate` date NOT NULL,
  `DeadlineDate` date NOT NULL,
  `MaxHours` int(11) NOT NULL,
  `isSubTask` tinyint(1) NOT NULL DEFAULT '0',
  `Rating` int(11) NOT NULL,
  PRIMARY KEY (`idTask`),
  KEY `idProject` (`idProject`,`idUserAssignedTo`,`idParentTask`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tasks`
--

LOCK TABLES `Tasks` WRITE;
/*!40000 ALTER TABLE `Tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `Tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserAbility`
--

DROP TABLE IF EXISTS `UserAbility`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserAbility` (
  `idUser` int(11) NOT NULL,
  `idAbility` int(11) NOT NULL,
  `Level` int(5) NOT NULL,
  KEY `idUser` (`idUser`,`idAbility`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserAbility`
--

LOCK TABLES `UserAbility` WRITE;
/*!40000 ALTER TABLE `UserAbility` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserAbility` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `idUser` int(11) NOT NULL AUTO_INCREMENT,
  `idUserCreatedBy` int(11) NOT NULL,
  `LoginName` varchar(20) COLLATE utf8_czech_ci NOT NULL,
  `Name` varchar(40) COLLATE utf8_czech_ci NOT NULL,
  `Password` varchar(32) COLLATE utf8_czech_ci NOT NULL,
  `permAdmin` tinyint(1) NOT NULL DEFAULT '0',
  `permLeader` tinyint(1) NOT NULL DEFAULT '0',
  `permPersonalist` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idUser`),
  UNIQUE KEY `LoginName` (`LoginName`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (1,-1,'root','The Root','955db0b81ef1989b4a4dfeae8061a9a6',1,1,1),(7,1,'lachike','Lachim Kečuos','955db0b81ef1989b4a4dfeae8061a9a6',0,0,1),(6,1,'mychaso','Mychal Soušek','955db0b81ef1989b4a4dfeae8061a9a6',0,0,1),(5,1,'pepanov','Pepa Novák','955db0b81ef1989b4a4dfeae8061a9a6',0,0,0);
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-12-05 16:52:35
